@extends('layouts.main');

@section('title', 'MAILOS - Par mums')

@section('content');

@endsection