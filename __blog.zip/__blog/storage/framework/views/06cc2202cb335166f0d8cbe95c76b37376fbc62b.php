<?php $__env->startSection('title'); ?>
    <?php echo $post->title; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('linkBeginning', '../'); ?>
<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="./../css/owl.carousel.css">
    <link rel="stylesheet" href="./../css/owl.theme.default.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bodyTag'); ?>
    class="bg-gray"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
    <?php echo $post->body; ?>

      
<div class="mx-md-5 px-md-5">
    <div class="kontakti-bg">
        <h1 class="text-center red h3 py-4">CITI RAKSTI</h1>
            <section>
                <div class="brand-carousel owl-carousel container citi-raksti-size position-relative px-5">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <?php if($item->id != $post->id): ?> 
                    <div class="single-logo partneri-box">
                        <a href="/jaunumi/<?php echo e($item->id); ?>" class="h-40">
                            <div class="d-flex justify-content-center">
                                <img src="./.<?php echo e($item->img); ?>" alt="Raksta attēls" class="citi-raksti-img">
                            </div>
                            <h2 class="red h5 text-center pt-3"><?php echo e($item->title); ?></h2>
                        </a>
                    </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo $post->scripts; ?>)
    <script src="./../js/jquery-3.2.1.min.js"></script>
    <script src="./../Js/owl.carousel.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\__blog\resources\views/pages/jaunumi-item.blade.php ENDPATH**/ ?>