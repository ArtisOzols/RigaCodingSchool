<?php $__env->startComponent('mail::message'); ?>
    <strong>Vārds:</strong> <?php echo e($data['name']); ?> <br>
    <strong>Telefona Nr.:</strong> <?php echo e($data['phoneCode']); ?>

    <strong></strong> <?php echo e($data['phone']); ?> <br>
    <strong>Epasta adrese:</strong> <?php echo e($data['email']); ?> <br>
    <strong>Datums:</strong> <?php echo e($data['date']); ?> <br>
    <strong>Laiks:</strong> <?php echo e($data['time']); ?> <br>
    <strong>Ziņojuma teksts:</strong> <br>
    <?php echo e($data['comment']); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\__blog\resources\views/emails.blade.php ENDPATH**/ ?>