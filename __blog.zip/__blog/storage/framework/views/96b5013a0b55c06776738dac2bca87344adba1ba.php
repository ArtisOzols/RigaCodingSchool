;

<?php $__env->startSection('title', 'Mailos - Veselības un skaistumkopšanas centrs'); ?>

<?php $__env->startSection('content'); ?>;

<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <div class="card">
        <img src="<?php echo e($postItem->img); ?>" alt="">
        <h2 class="title"><?php echo e($postItem->title); ?></h2>
        <p><?php echo e($postItem->excert); ?></p>
        <span class="time"><?php echo e($postItem->created_at->diffForHumans()); ?></span>
        <a href="/blog/<?php echo e($postItem->id); ?>">GO TO POST</a>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<p>TEKSTS</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\__blog\resources\views/pages/blog.blade.php ENDPATH**/ ?>