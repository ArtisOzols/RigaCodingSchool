<?php $__env->startSection('title', 'MAILOS - Jaunumi'); ?>

<?php $__env->startSection('bodyTag'); ?>
    class="bg-gray"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="kontakti-bg mx-2 mx-md-5">
    <h1 class="title text-center text-md-left">Jaunākie raksti</h1>
    <div class="mt-5 px-md-5 px-3">
        <div class="row d-flex justify-content-center mb-5">
            <div class="col-12 col-md-9 px-0 raksta-bg pb-md-0">
                    <a href="/jaunumi/<?php echo e($onePost[0]->id); ?>" class="d-block pb-3">
                        <div class="d-flex justify-content-center jaunākā-raksta-h">
                            <img src="<?php echo e($onePost[0]->img); ?>" alt="Raksta attēls" class="raksti-img">
                        </div>
                        <div class="px-4">
                            <h2 class="red h4 text-center pt-3"><?php echo e($onePost[0]->title); ?></h2>
                            <?php echo $onePost[0]->excert_short; ?>

                            <span class="time"><?php echo e($onePost[0]->created_at->diffForHumans()); ?></span>
                        </div>
                    </a>
            </div>
        </div>
        <div class="row d-flex justify-content-center">
            <?php $__currentLoopData = $restOfPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <div class="col-12 col-md-5 col-lg-3 raksta-bg raksta-min-h mb-5 mx-md-3 pt-3">
                    <a href="/jaunumi/<?php echo e($postItem->id); ?>" class="d-block pb-3">
                        <div class="d-flex justify-content-center h-40">
                            <img src="<?php echo e($postItem->img); ?>" alt="Raksta attēls" class="raksti-img">
                        </div>
                        <h2 class="red h4 text-center pt-3"><?php echo e($postItem->title); ?></h2>
                        <?php echo $postItem->excert_short; ?>

                        <span class="time"><?php echo e($postItem->created_at->diffForHumans()); ?></span>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\__blog\resources\views/pages/jaunumi.blade.php ENDPATH**/ ?>