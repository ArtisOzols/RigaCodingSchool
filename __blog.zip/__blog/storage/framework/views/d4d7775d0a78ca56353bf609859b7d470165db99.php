<?php $__env->startSection('title', 'MAILOS - Raksti'); ?>

<?php $__env->startSection('bodyTag'); ?>
    class="bg-gray"
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="kontakti-bg">
    <h1 class="title text-center text-md-left">Jaunākie raksti</h1>
    <div class="mt-5 px-5">
        <div class="row d-flex justify-content-center">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <div class="col-12 col-md-5 col-lg-3 raksta-bg raksta-min-h mx-md-3 py-3 mb-5">
                            <a href="/raksti/<?php echo e($postItem->id); ?>">
                                <div class="d-flex justify-content-center h-40">
                                    <img src="<?php echo e($postItem->img); ?>" alt="Raksta attēls" class="raksti-img">
                                </div>
                                <h2 class="red h4 text-center pt-3"><?php echo e($postItem->title); ?></h2>
                                <p><?php echo $postItem->excert_short; ?></p>
                                <span class="time"><?php echo e($postItem->created_at->diffForHumans()); ?></span>
                            </a>
                        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\__blog\resources\views/pages/raksti.blade.php ENDPATH**/ ?>